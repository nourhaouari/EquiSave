<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$stmt = $pdo->query("SELECT * FROM submissions ORDER BY submitted_on DESC");
$submissions = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Soumissions - EquiSave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: linear-gradient(to right, #f1f5f9, #e2e8f0);
    }
  </style>
</head>

<body class="flex font-sans text-gray-800">

  <!-- Sidebar -->
  <aside class="w-64 h-screen bg-[#1e293b] text-white shadow-lg flex flex-col">
    <div class="text-3xl font-bold text-white px-6 py-6 border-b border-slate-700">EquiSave</div>
    <nav class="flex-1 px-6 py-6 space-y-6 text-lg tracking-wide">
      <a href="dashboard.php" class="block hover:text-sky-300">🏠 Dashboard</a>
      <a href="equipment.php" class="block hover:text-sky-300">🩺 Équipements</a>
      <a href="inventory.php" class="block hover:text-sky-300">📦 Inventaire</a>
      <a href="submissions.php" class="block font-semibold text-sky-400">📝 Soumissions</a>
      <a href="users.php" class="block hover:text-sky-300">👤 Utilisateurs</a>
      <a href="historique_maintenance.php" class="block hover:text-sky-300">🛠️ Historique Maintenance</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-10">

    <!-- Header -->
    <div class="flex justify-between items-center mb-10">
      <h1 class="text-4xl font-bold text-slate-800">📝 Liste des Soumissions</h1>
      <a href="submit_form.php" class="bg-sky-600 text-white px-6 py-2 rounded-md text-base hover:bg-sky-700 transition">
        ➕ Nouvelle soumission
      </a>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-lg shadow-lg overflow-x-auto">
      <table class="min-w-full text-base text-left text-slate-700">
        <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
          <tr>
            <th class="px-6 py-4">Nom</th>
            <th class="px-6 py-4">Email</th>
            <th class="px-6 py-4">Message</th>
            <th class="px-6 py-4">Date</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
          <?php foreach ($submissions as $sub): ?>
            <tr class="hover:bg-slate-50 transition">
              <td class="px-6 py-4 font-medium"><?= htmlspecialchars($sub['name']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($sub['email']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($sub['submission']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($sub['submitted_on']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
      <?php if (isset($_GET['added'])): ?>
  <div class="mb-6 bg-green-100 border-l-4 border-green-500 text-green-800 p-4 rounded">
    ✅ La soumission a été enregistrée avec succès.
  </div>
<?php endif; ?>

    </div>

  </main>
</body>
</html>

