-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1
-- Généré le : ven. 02 mai 2025 à 21:46
-- Version du serveur : 10.4.32-MariaDB
-- Version de PHP : 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `equisave_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `devices`
--

CREATE TABLE `devices` (
  `device_id` varchar(20) NOT NULL,
  `device_type` varchar(100) DEFAULT NULL,
  `usage_hours` float DEFAULT NULL,
  `internal_temperature` float DEFAULT NULL,
  `power_cycles` int(11) DEFAULT NULL,
  `voltage_stability` float DEFAULT NULL,
  `error_log_count` int(11) DEFAULT NULL,
  `fan_speed` float DEFAULT NULL,
  `disk_health` float DEFAULT NULL,
  `battery_level` float DEFAULT NULL,
  `software_status` tinyint(1) DEFAULT NULL,
  `sensor_calibration_deviation` float DEFAULT NULL,
  `last_maintenance_days_ago` int(11) DEFAULT NULL,
  `ambient_conditions_risk` float DEFAULT NULL,
  `operational_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `devices`
--

INSERT INTO `devices` (`device_id`, `device_type`, `usage_hours`, `internal_temperature`, `power_cycles`, `voltage_stability`, `error_log_count`, `fan_speed`, `disk_health`, `battery_level`, `software_status`, `sensor_calibration_deviation`, `last_maintenance_days_ago`, `ambient_conditions_risk`, `operational_status`) VALUES
('DEV-0001', 'Rerspirateur', 7126.3, 39.6, 26, 2.68, 1, 0, 0, 49.2, 1, 0, 275, 0, 'maintenance_needed'),
('DEV-007888', 'Rerspirateur', 5630.9, 37.7, 22, 4.66, 2, 1165, 0, 0, 1, 0, 0, 0, 'normal'),
('DEV-008', 'Monitor', 6669, 31.5, 26, 4.77, 1, 0, 0, 0, 1, 4.19, 68, 0, 'normal'),
('DEV-009', 'Rerspirateur', 4891.9, 34.1, 33, 3.25, 0, 1354, 0, 0, 1, 0, 0, 0, 'normal'),
('DEV-1010', 'Moniteur', 6669, 31.5, 32, 4.47, 1, NULL, NULL, 49.2, 0, 1.09, 275, 0.49, 'normal'),
('DEV-2000', 'Moniteur', 6669, 31.5, 32, 4.47, 1, NULL, NULL, 49.2, 0, 1.09, 275, 0.49, 'défaillant'),
('DEV-2001', 'Respirateur', 7126.3, 39.6, 26, 2.68, 1, 1952, NULL, 86.7, 0, 3.63, 263, 0.2, 'critical_error'),
('DEV-2002', 'Respirateur', 4891.9, 34.1, 33, 3.25, 0, 1354, NULL, 73.5, 0, 2.76, 57, 0.02, 'hors service'),
('DEV-2003', 'Respirateur', 5630.9, 37.7, 22, 4.66, 2, 1165, NULL, 60.5, 0, 3.62, 63, 0.24, 'hors service'),
('DEV-2004', 'ECG', 1897.8, 43.2, 26, 0.88, 0, NULL, NULL, NULL, 1, 1.47, 244, 0.69, 'critical_error'),
('DEV-2005', 'ECG', 4950.2, 37, 30, 4.89, 0, NULL, NULL, NULL, 1, 0.51, 298, 0.68, 'maintenance'),
('DEV-2006', 'Respirateur', 2580.4, 35.6, 25, 3.7, 1, 1602, NULL, 91.4, 0, 2.96, 181, 0.02, 'défaillant'),
('DEV-2007', 'ECG', 6669, 30, 33, 4.47, 1, 1165, 0, 0, 0, 0, 0, 0, 'maintenance_needed');

-- --------------------------------------------------------

--
-- Structure de la table `maintenance_logs`
--

CREATE TABLE `maintenance_logs` (
  `log_id` int(11) NOT NULL,
  `device_id` varchar(20) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `action` text DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `notes` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `maintenance_logs`
--

INSERT INTO `maintenance_logs` (`log_id`, `device_id`, `user_id`, `action`, `timestamp`, `notes`) VALUES
(9, 'DEV-2000', 3, 'Vérification des capteurs', '2025-04-11 17:39:40', 'Analyse périodique mensuelle.'),
(10, 'DEV-2001', 2, 'Mise à jour logicielle', '2025-03-30 10:15:00', 'Ajout des derniers correctifs de performance.'),
(11, 'DEV-2002', 1, 'Remplacement du ventilateur', '2025-04-07 09:25:00', 'Ventilateur bruyant détecté durant l’utilisation.'),
(12, 'DEV-2003', 4, 'Réinitialisation du système', '2024-12-12 16:00:00', 'Suite à un bug critique signalé.'),
(13, 'DEV-2004', 3, 'Nettoyage interne', '2024-08-21 13:30:00', 'Intervention de maintenance préventive.'),
(14, 'DEV-2005', 1, 'Réinitialisation du système', '2025-03-07 14:45:00', 'Réponse à une erreur intermittente.'),
(18, 'DEV-2006', 4, 'Controle Qualité', '2025-05-02 20:10:12', 'Reglage salle 2 ');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(150) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `sku` varchar(50) DEFAULT NULL,
  `category` varchar(100) DEFAULT NULL,
  `photo_url` text DEFAULT NULL,
  `warehouse` varchar(100) DEFAULT NULL,
  `registered_by` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `description`, `price`, `sku`, `category`, `photo_url`, `warehouse`, `registered_by`) VALUES
(1, 'Capteur ECG', 'Capteur réutilisable pour ECG.', 30.00, 'ECG-001', 'Capteurs', NULL, 'GE Healthcare', 'Ahmed'),
(2, 'Batterie Moniteur', 'Batterie pour moniteur série A.', 120.00, 'BAT-100', 'Batteries', NULL, 'Philips Medical', 'Fatima'),
(3, 'Câble SpO2', 'Câble de connexion SpO2.', 45.00, 'SPO2-002', 'Accessoires', NULL, 'Nellcor', 'Mohamed'),
(4, 'Gel Échographie', 'Gel conducteur hypoallergénique.', 5.50, 'GEL-003', 'Consommables', NULL, 'Parker Laboratories', 'Zahra'),
(5, 'Filtre Respirateur', 'Filtre HEPA pour respirateur médical.', 20.00, 'FLT-005', 'Filtres', NULL, '3M Health Care', 'Yassir'),
(8, 'Defibrillateur (DAE)', 'Appareil portable pour intervenir en cas d\'arret cardiaque', 995.00, 'DAE-450', 'Urgence', '', 'Entrepot SUD', 'Equi Test');

-- --------------------------------------------------------

--
-- Structure de la table `submissions`
--

CREATE TABLE `submissions` (
  `submission_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `submission` text DEFAULT NULL,
  `submitted_on` datetime DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `submissions`
--

INSERT INTO `submissions` (`submission_id`, `name`, `email`, `submission`, `submitted_on`) VALUES
(1, 'flen', 'test1@test.com', 'Erreur sur moniteur salle 1.', '2025-04-25 20:13:20'),
(2, 'fatima', 'test2@test.com', 'Scanner salle 2 ne démarre pas.', '2025-04-25 20:13:20'),
(3, 'nour', 'test3@test.com', 'Demande remplacement capteur SpO2.', '2025-04-25 20:13:20'),
(4, 'mohamed ali', 'test4@test.com', 'Problème calibration ECG portable.', '2025-04-25 20:13:20'),
(10, 'Test Equisave', 'testequisave@gmail.com', 'Verification capteur', '2025-05-02 19:58:21'),
(11, 'Equi Test', 'equitest1@equisave.com', 'Controle salle 2', '2025-05-02 20:09:12');

-- --------------------------------------------------------

--
-- Structure de la table `users`
--

CREATE TABLE `users` (
  `user_id` int(11) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `role` enum('Technician','Engineer','Admin','Specialist') DEFAULT NULL,
  `job_title` varchar(100) DEFAULT NULL,
  `photo_url` text DEFAULT NULL,
  `password_hash` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Déchargement des données de la table `users`
--

INSERT INTO `users` (`user_id`, `name`, `email`, `role`, `job_title`, `photo_url`, `password_hash`) VALUES
(1, 'flen fouleni', 'flenfouleni@gmail.com', 'Technician', 'technicien', NULL, '$2y$10$vJsxaa5ufCeMzCDaTARGIuTlziYBkY7a6iH4ChCBSgc/mVkAVlKpa'),
(2, 'Ahmed Yassir', 'ahmed@equisave.com', 'Admin', 'Responsable Biomédical', NULL, '$2y$10$vJsxaa5ufCeMzCDaTARGIuTlziYBkY7a6iH4ChCBSgc/mVkAVlKpa'),
(3, 'Fatima Zahra', 'fatima@equisave.com', 'Technician', 'Technicienne Maintenance', NULL, '$2y$10$vJsxaa5ufCeMzCDaTARGIuTlziYBkY7a6iH4ChCBSgc/mVkAVlKpa'),
(4, 'Mohamed Ali', 'mohamed@equisave.com', 'Engineer', 'Ingénieur Données', NULL, '$2y$10$vJsxaa5ufCeMzCDaTARGIuTlziYBkY7a6iH4ChCBSgc/mVkAVlKpa'),
(7, 'Nour Haouari', 'norhaouarinour@gmail.com', 'Technician', 'technicien', NULL, '$2y$10$ftWigiA9w1C2b7dp2pvV5ul22XP6i6qPlPoGw8rkyhqIjRciIWoFi'),
(17, 'Equi Test', 'equitest1@equisave.com', 'Admin', 'admin', NULL, '$2y$10$x7MyGRmLqT.4sCPgwW15PenhmsSFIA0oCY/Vs6XlJtPKcupj6t0OK');

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `devices`
--
ALTER TABLE `devices`
  ADD PRIMARY KEY (`device_id`);

--
-- Index pour la table `maintenance_logs`
--
ALTER TABLE `maintenance_logs`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `device_id` (`device_id`),
  ADD KEY `user_id` (`user_id`);

--
-- Index pour la table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Index pour la table `submissions`
--
ALTER TABLE `submissions`
  ADD PRIMARY KEY (`submission_id`);

--
-- Index pour la table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `maintenance_logs`
--
ALTER TABLE `maintenance_logs`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT pour la table `products`
--
ALTER TABLE `products`
  MODIFY `product_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT pour la table `submissions`
--
ALTER TABLE `submissions`
  MODIFY `submission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT pour la table `users`
--
ALTER TABLE `users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `maintenance_logs`
--
ALTER TABLE `maintenance_logs`
  ADD CONSTRAINT `maintenance_logs_ibfk_1` FOREIGN KEY (`device_id`) REFERENCES `devices` (`device_id`),
  ADD CONSTRAINT `maintenance_logs_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
