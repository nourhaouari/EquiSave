<?php
// Activer l'affichage des erreurs PHP
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Préparer des données de test (les mêmes attendues par le modèle IA)
$input_data = [
    5000,     // usage_hours
    37.5,     // internal_temperature
    30,       // power_cycles
    3.5,      // voltage_stability
    1,        // error_log_count
    1500,     // fan_speed
    95,       // disk_health
    70,       // battery_level
    0,        // software_status
    2.5,      // sensor_calibration_deviation
    120,      // last_maintenance_days_ago
    0.2       // ambient_conditions_risk
];

// Appel à l'API Flask
$data = ['input_data' => $input_data];
$options = [
    'http' => [
        'method'  => 'POST',
        'header'  => "Content-Type: application/json",
        'content' => json_encode($data)
    ]
];

$context = stream_context_create($options);
$response = @file_get_contents("http://127.0.0.1:5000/predict", false, $context);

if ($response === false) {
    echo "<h2 style='color:red;'>❌ Erreur : API IA non joignable sur http://127.0.0.1:5000/predict</h2>";
    exit;
}

$result = json_decode($response, true);

if (!isset($result['prediction'])) {
    echo "<h2 style='color:red;'>❌ Erreur : réponse invalide reçue : <pre>" . htmlspecialchars($response) . "</pre></h2>";
    exit;
}

// Afficher la prédiction
echo "<h2 style='color:green;'>✅ Statut prédit par l'IA : <strong>" . $result['prediction'] . "</strong></h2>";
?>
