<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $submission = $_POST['submission'];

    $stmt = $pdo->prepare("INSERT INTO submissions (name, email, submission) VALUES (?, ?, ?)");
    $stmt->execute([$name, $email, $submission]);

    // ✅ Rediriger vers la liste des soumissions avec notification
    header("Location: submissions.php?added=1");
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Nouvelle Soumission - EquiSave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="min-h-screen bg-gradient-to-br from-slate-100 to-slate-200 flex items-center justify-center">

  <form method="POST" class="bg-white shadow-lg rounded-lg p-8 w-full max-w-xl space-y-6 border">
    <h2 class="text-3xl font-bold text-center text-slate-800">📝 Nouvelle Soumission</h2>

    <div>
      <label class="block text-gray-700 mb-1 font-semibold">Nom</label>
      <input type="text" name="name" required class="w-full p-2 border border-gray-300 rounded focus:ring focus:ring-sky-200">
    </div>

    <div>
      <label class="block text-gray-700 mb-1 font-semibold">Email</label>
      <input type="email" name="email" required class="w-full p-2 border border-gray-300 rounded focus:ring focus:ring-sky-200">
    </div>

    <div>
      <label class="block text-gray-700 mb-1 font-semibold">Message</label>
      <textarea name="submission" rows="4" required class="w-full p-2 border border-gray-300 rounded focus:ring focus:ring-sky-200"></textarea>
    </div>

    <div class="flex justify-between items-center">
      <a href="submissions.php" class="text-sky-600 hover:underline text-sm">⬅ Retour à la liste</a>
      <button type="submit" class="bg-sky-600 text-white px-6 py-2 rounded hover:bg-sky-700 transition">Envoyer ✉️</button>
    </div>
  </form>

</body>
</html>
