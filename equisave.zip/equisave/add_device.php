<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
include 'db.php';
session_start();

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    function cleanFloat($v) {
        return is_numeric(str_replace(',', '.', $v)) ? floatval(str_replace(',', '.', $v)) : 0.0;
    }

    $input_data = [
        cleanFloat($_POST['usage_hours']),
        cleanFloat($_POST['internal_temperature']),
        cleanFloat($_POST['power_cycles']),
        cleanFloat($_POST['voltage_stability']),
        cleanFloat($_POST['error_log_count']),
        cleanFloat($_POST['fan_speed']),
        cleanFloat($_POST['disk_health']),
        cleanFloat($_POST['battery_level']),
        intval($_POST['software_status']),
        cleanFloat($_POST['sensor_calibration_deviation']),
        intval($_POST['last_maintenance_days_ago']),
        cleanFloat($_POST['ambient_conditions_risk'])
    ];

    $predicted_status = $_POST['predicted_status'] ?? 'inconnu';
    $predicted_status = strtolower(trim(preg_replace('/\s+/', ' ', $predicted_status)));

    $stmt = $pdo->prepare("INSERT INTO devices (
        device_id, device_type, usage_hours, internal_temperature, operational_status,
        power_cycles, voltage_stability, error_log_count, fan_speed, disk_health,
        battery_level, software_status, sensor_calibration_deviation, last_maintenance_days_ago, ambient_conditions_risk
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");

    $stmt->execute([
        $_POST['device_id'],
        $_POST['device_type'],
        $input_data[0],
        $input_data[1],
        $predicted_status,
        $input_data[2],
        $input_data[3],
        $input_data[4],
        $input_data[5],
        $input_data[6],
        $input_data[7],
        $input_data[8],
        $input_data[9],
        $input_data[10],
        $input_data[11]
    ]);

    header('Location: equipment.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Ajouter un Appareil</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 p-6">
  <h1 class="text-2xl font-bold text-center mb-6">Ajouter un Appareil</h1>

  <form method="POST" onsubmit="return syncPrediction()" id="deviceForm" class="max-w-2xl mx-auto bg-white p-6 rounded shadow space-y-2">
    <label>ID Appareil :</label><input name="device_id" required class="w-full border p-2">
    <label>Type :</label><input name="device_type" required class="w-full border p-2">
    <label>Usage Hours :</label><input name="usage_hours" required class="w-full border p-2">
    <label>Internal Temperature :</label><input name="internal_temperature" required class="w-full border p-2">
    <label>Power Cycles :</label><input name="power_cycles" class="w-full border p-2">
    <label>Voltage Stability :</label><input name="voltage_stability" class="w-full border p-2">
    <label>Error Log Count :</label><input name="error_log_count" class="w-full border p-2">
    <label>Fan Speed :</label><input name="fan_speed" class="w-full border p-2">
    <label>Disk Health :</label><input name="disk_health" class="w-full border p-2">
    <label>Battery Level :</label><input name="battery_level" class="w-full border p-2">
    <label>Software Status :</label><input name="software_status" class="w-full border p-2">
    <label>Sensor Calibration Deviation :</label><input name="sensor_calibration_deviation" class="w-full border p-2">
    <label>Last Maintenance Days Ago :</label><input name="last_maintenance_days_ago" class="w-full border p-2">
    <label>Ambient Conditions Risk :</label><input name="ambient_conditions_risk" class="w-full border p-2">

    <input type="hidden" name="predicted_status" id="predicted_status_input">

    <div class="mt-4 text-lg">
      🧠 <strong>Statut Prédit :</strong>
      <span id="predictionResult" class="font-semibold text-blue-700">En attente...</span>
    </div>

    <button class="bg-blue-600 text-white px-4 py-2 rounded mt-4">✅ Ajouter</button>
  </form>

  <script>
    const fields = document.querySelectorAll('input[name]');
    const resultSpan = document.getElementById('predictionResult');
    const hiddenInput = document.getElementById('predicted_status_input');

    const getValues = () => [
      parseFloat(document.querySelector('[name="usage_hours"]').value) || 0,
      parseFloat(document.querySelector('[name="internal_temperature"]').value) || 0,
      parseFloat(document.querySelector('[name="power_cycles"]').value) || 0,
      parseFloat(document.querySelector('[name="voltage_stability"]').value) || 0,
      parseFloat(document.querySelector('[name="error_log_count"]').value) || 0,
      parseFloat(document.querySelector('[name="fan_speed"]').value) || 0,
      parseFloat(document.querySelector('[name="disk_health"]').value) || 0,
      parseFloat(document.querySelector('[name="battery_level"]').value) || 0,
      parseInt(document.querySelector('[name="software_status"]').value) || 0,
      parseFloat(document.querySelector('[name="sensor_calibration_deviation"]').value) || 0,
      parseInt(document.querySelector('[name="last_maintenance_days_ago"]').value) || 0,
      parseFloat(document.querySelector('[name="ambient_conditions_risk"]').value) || 0
    ];

    function updatePrediction() {
      const data = { input_data: getValues() };

      fetch("http://127.0.0.1:5000/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
      })
      .then(res => res.json())
      .then(json => {
        const predicted = json.prediction || "inconnu";
        resultSpan.textContent = predicted;
        hiddenInput.value = predicted;
      })
      .catch(() => {
        resultSpan.textContent = "API non joignable";
        hiddenInput.value = "inconnu";
      });
    }

    function syncPrediction() {
      const prediction = resultSpan.textContent.trim().toLowerCase();
      if (prediction === "en attente...") {
        alert("Veuillez attendre la prédiction avant de soumettre.");
        return false;
      }
      hiddenInput.value = resultSpan.textContent.trim();
      return true;
    }

    fields.forEach(field => field.addEventListener('input', updatePrediction));
  </script>
</body>
</html>




