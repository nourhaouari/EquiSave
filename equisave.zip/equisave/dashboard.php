<?php
include 'db.php';
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}

$equipments = $pdo->query("SELECT operational_status, COUNT(*) as count FROM devices GROUP BY operational_status")->fetchAll(PDO::FETCH_ASSOC);
$users = $pdo->query("SELECT role, COUNT(*) as count FROM users GROUP BY role")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Dashboard - EquiSave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
  <style>
    body {
      background: linear-gradient(to right, #f8fafc, #f1f5f9);
    }
  </style>
</head>

<body class="flex font-sans text-gray-800">

  <!-- Sidebar -->
  <aside class="w-64 h-screen bg-[#1e293b] text-white shadow-lg flex flex-col">
    <div class="text-3xl font-bold text-white px-6 py-6 border-b border-slate-700">EquiSave</div>
    <nav class="flex-1 px-6 py-6 space-y-6 text-lg tracking-wide">
      <a href="dashboard.php" class="block font-semibold text-sky-400 hover:text-sky-300">🏠 Dashboard</a>
      <a href="equipment.php" class="block hover:text-sky-300">🩺 Équipements</a>
      <a href="inventory.php" class="block hover:text-sky-300">📦 Inventaire</a>
      <a href="submissions.php" class="block hover:text-sky-300">📝 Soumissions</a>
      <a href="users.php" class="block hover:text-sky-300">👤 Utilisateurs</a>
      <a href="historique_maintenance.php" class="block hover:text-sky-300">🛠️ Historique Maintenance</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-10">

    <!-- Header -->
    <div class="flex flex-col md:flex-row justify-between items-start md:items-center mb-10">
      <h1 class="text-4xl font-bold text-slate-800 mb-4 md:mb-0">📊 Tableau de bord</h1>
      <div class="bg-blue-100 text-blue-800 px-6 py-3 rounded-full shadow text-sm md:text-base">
        Bienvenue, <strong><?= htmlspecialchars($_SESSION['user_name']) ?></strong> 👋
        <a href="logout.php" class="ml-4 underline text-blue-600 hover:text-blue-800">Déconnexion</a>
      </div>
    </div>

    <!-- Dashboard Cards -->
    <div class="grid grid-cols-1 md:grid-cols-3 gap-6 mb-10">
      <div class="bg-white p-6 rounded-lg shadow text-center">
        <h2 class="text-md font-semibold text-gray-500">Équipements Totaux</h2>
        <p class="text-4xl text-sky-600 font-bold mt-2"><?= array_sum(array_column($equipments, 'count')) ?></p>
      </div>
      <div class="bg-white p-6 rounded-lg shadow text-center">
        <h2 class="text-md font-semibold text-gray-500">Utilisateurs</h2>
        <p class="text-4xl text-green-600 font-bold mt-2"><?= array_sum(array_column($users, 'count')) ?></p>
      </div>
      <div class="bg-white p-6 rounded-lg shadow text-center">
        <h2 class="text-md font-semibold text-gray-500">Maintenance Active</h2>
        <p class="text-4xl text-red-500 font-bold mt-2">
          <?php
          $maintenance = 0;
          $statuses_to_count = ['maintenance', 'maintenance_needed', 'défaillant', 'critical_error'];
          foreach ($equipments as $eq) {
              $status = strtolower(trim($eq['operational_status']));
              if (in_array($status, $statuses_to_count)) {
                  $maintenance += $eq['count'];
              }
          }
          echo $maintenance;
          ?>
        </p>
      </div>
    </div>

    <!-- Charts -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
      <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-semibold mb-4">📟 Statut des Équipements</h2>
        <canvas id="equipmentChart"></canvas>
      </div>
      <div class="bg-white p-6 rounded-lg shadow-md">
        <h2 class="text-xl font-semibold mb-4">👥 Répartition des Utilisateurs</h2>
        <canvas id="userChart"></canvas>
      </div>
    </div>

  </main>

<!-- Chart.js Setup -->
<script>
const equipmentData = {
  labels: <?= json_encode(array_column($equipments, 'operational_status')) ?>,
  datasets: [{
    label: 'Nombre',
    data: <?= json_encode(array_column($equipments, 'count')) ?>,
    backgroundColor: ['#4ade80', '#f87171', '#facc15', '#60a5fa']
  }]
};

const userData = {
  labels: <?= json_encode(array_column($users, 'role')) ?>,
  datasets: [{
    label: 'Nombre',
    data: <?= json_encode(array_column($users, 'count')) ?>,
    backgroundColor: ['#60a5fa', '#fbbf24', '#34d399', '#f472b6']
  }]
};

new Chart(document.getElementById('equipmentChart'), {
  type: 'pie',
  data: equipmentData
});

new Chart(document.getElementById('userChart'), {
  type: 'doughnut',
  data: userData
});
</script>

</body>
</html>
