<?php
include 'db.php';
session_start();

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $stmt = $pdo->prepare("INSERT INTO maintenance_logs (device_id, user_id, action, timestamp, notes)
                           VALUES (?, ?, ?, NOW(), ?)");
    $stmt->execute([
        $_POST['device_id'],
        $_POST['user_id'],
        $_POST['action'],
        $_POST['notes']
    ]);
    header("Location: historique_maintenance.php");
    exit();
}

$stmt = $pdo->query("SELECT * FROM maintenance_logs ORDER BY timestamp DESC");
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Historique de maintenance</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: linear-gradient(to right, #f8fafc, #f1f5f9);
    }
  </style>
</head>

<body class="bg-gray-50 font-sans flex text-gray-800">

  <!-- Sidebar -->
  <aside class="w-64 h-screen bg-[#1e293b] text-white shadow-lg flex flex-col">
    <div class="text-3xl font-bold text-white px-6 py-6 border-b border-slate-700">EquiSave</div>
    <nav class="flex-1 px-6 py-6 space-y-6 text-lg tracking-wide">
      <a href="dashboard.php" class="block hover:text-sky-300">🏠 Dashboard</a>
      <a href="equipment.php" class="block hover:text-sky-300">🩺 Équipements</a>
      <a href="inventory.php" class="block hover:text-sky-300">📦 Inventaire</a>
      <a href="submissions.php" class="block hover:text-sky-300">📝 Soumissions</a>
      <a href="users.php" class="block hover:text-sky-300">👤 Utilisateurs</a>
      <a href="historique_maintenance.php" class="block font-semibold text-sky-400">🛠️ Historique Maintenance</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-10">
    <!-- Header -->
    <div class="flex justify-between items-center mb-8">
      <h1 class="text-4xl font-bold text-slate-800">🛠️ Historique de Maintenance</h1>
      <button onclick="document.getElementById('formDiv').classList.toggle('hidden')" class="bg-sky-600 text-white px-6 py-2 rounded hover:bg-sky-700 transition">
        ➕ Nouvelle entrée
      </button>
    </div>

    <!-- Add Form -->
    <div id="formDiv" class="mb-10 hidden">
      <form method="POST" class="bg-white p-6 rounded-lg shadow space-y-4 max-w-2xl">
        <div>
          <label class="block mb-1 font-medium">Appareil (device_id)</label>
          <input type="text" name="device_id" required class="w-full border p-2 rounded">
        </div>
        <div>
          <label class="block mb-1 font-medium">Utilisateur (user_id)</label>
          <input type="number" name="user_id" required class="w-full border p-2 rounded">
        </div>
        <div>
          <label class="block mb-1 font-medium">Action</label>
          <input type="text" name="action" required class="w-full border p-2 rounded">
        </div>
        <div>
          <label class="block mb-1 font-medium">Notes</label>
          <textarea name="notes" class="w-full border p-2 rounded"></textarea>
        </div>
        <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">💾 Enregistrer</button>
      </form>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-lg shadow overflow-x-auto">
      <table class="min-w-full text-base text-left text-slate-700">
        <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
          <tr>
            <th class="px-6 py-3">Log ID</th>
            <th class="px-6 py-3">Appareil</th>
            <th class="px-6 py-3">Utilisateur</th>
            <th class="px-6 py-3">Action</th>
            <th class="px-6 py-3">Date</th>
            <th class="px-6 py-3">Notes</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
          <?php foreach ($logs as $row): ?>
            <tr class="hover:bg-slate-50 transition">
              <td class="px-6 py-4"><?= htmlspecialchars($row['log_id']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($row['device_id']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($row['user_id']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($row['action']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($row['timestamp']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($row['notes']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </main>
</body>
</html>
