import sys
import joblib
import pandas as pd

# Charger le modèle sauvegardé
model = joblib.load('model.pkl')  # ← modèle entraîné

# Lire les données depuis la ligne de commande
input_data = list(map(float, sys.argv[1:]))

# Colonnes dans le même ordre que l’entraînement
columns = ['Usage_Hours', 'Internal_Temperature', 'Power_Cycles', 'Voltage_Stability',
           'Error_Log_Count', 'Fan_Speed', 'Disk_Health', 'Battery_Level',
           'Software_Status', 'Sensor_Calibration_Deviation', 'Last_Maintenance_Days_Ago',
           'Ambient_Conditions_Risk']

df = pd.DataFrame([input_data], columns=columns)

# Prédiction
prediction = model.predict(df)[0]
print(prediction)
