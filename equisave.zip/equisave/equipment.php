<?php
include 'db.php';
$stmt = $pdo->query("SELECT * FROM devices");
$devices = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Équipements - EquiSave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: linear-gradient(to right, #f8fafc, #f1f5f9);
    }
  </style>
</head>

<body class="flex font-sans text-gray-800">

  <!-- Sidebar -->
  <aside class="w-64 h-screen bg-[#1e293b] text-white shadow-lg flex flex-col">
    <div class="text-3xl font-extrabold text-white px-6 py-6 border-b border-slate-700">EquiSave</div>
    <nav class="flex-1 px-6 py-6 space-y-6 text-lg tracking-wide">
      <a href="dashboard.php" class="block hover:text-sky-300">🏠 Dashboard</a>
      <a href="equipment.php" class="block font-semibold text-sky-400">🩺 Équipements</a>
      <a href="inventory.php" class="block hover:text-sky-300">📦 Inventaire</a>
      <a href="submissions.php" class="block hover:text-sky-300">📝 Soumissions</a>
      <a href="users.php" class="block hover:text-sky-300">👤 Utilisateurs</a>
      <a href="historique_maintenance.php" class="block hover:text-sky-300">🛠️ Historique Maintenance</a>
    </nav>
  </aside>

  <!-- Main Content -->
  <main class="flex-1 p-10 bg-transparent">

    <div class="flex justify-between items-center mb-10">
      <h1 class="text-4xl font-bold text-slate-800">📋 Équipements</h1>
      <a href="add_device.php" class="bg-sky-600 text-white px-6 py-2 rounded-md hover:bg-sky-700 transition">
        ➕ Ajouter un Appareil
      </a>
    </div>

    <div class="bg-white shadow-xl rounded-lg overflow-x-auto">
      <table class="min-w-full text-base text-left text-slate-700">
        <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
          <tr>
            <th class="px-6 py-4">ID</th>
            <th class="px-6 py-4">Type</th>
            <th class="px-6 py-4">Heures</th>
            <th class="px-6 py-4">Température</th>
            <th class="px-6 py-4">Statut</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
          <?php foreach ($devices as $device): ?>
            <tr class="hover:bg-slate-50 transition">
              <td class="px-6 py-4 font-medium"><?= htmlspecialchars($device['device_id']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($device['device_type']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($device['usage_hours']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($device['internal_temperature']) ?> °C</td>
              <td class="px-6 py-4">
                <?php
                  $status_raw = $device['operational_status'] ?? '';
                  $status = strtolower(trim(preg_replace('/\s+/', ' ', $status_raw)));

                  switch ($status) {
                    case 'normal':
                    case 'fonctionnel':
                      $label = "Fonctionnel";
                      $bg = "bg-green-100";
                      $text = "text-green-700";
                      break;

                    case 'maintenance':
                    case 'maintenance_needed':
                      $label = "Maintenance";
                      $bg = "bg-red-100";
                      $text = "text-red-600";
                      break;

                    case 'défaillant':
                    case 'defaillant':
                      $label = "Défaillant";
                      $bg = "bg-orange-100";
                      $text = "text-orange-700";
                      break;

                    case 'erreur critique':
                    case 'critical_error':
                      $label = "Erreur Critique";
                      $bg = "bg-yellow-100";
                      $text = "text-yellow-700";
                      break;

                    case 'out of service':
                    case 'hors service':
                      $label = "Hors Service";
                      $bg = "bg-black";
                      $text = "text-white";
                      break;

                    default:
                      $label = "Inconnu";
                      $bg = "bg-gray-200";
                      $text = "text-gray-600";
                      break;
                  }
                ?>
                <span class="inline-block <?= $bg ?> <?= $text ?> text-xs font-semibold px-3 py-1 rounded-full">
                  <?= $label ?>
                </span>
              </td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </main>
</body>
</html>
