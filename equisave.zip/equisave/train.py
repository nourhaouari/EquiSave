import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
import joblib

# Charger les données (modifie le chemin si nécessaire)
df = pd.read_csv("dataset_machines_médicales (1).csv")

# Adapter les noms de colonnes si nécessaire
X = df.drop(columns=["operational_status", "device_id", "device_type"], errors="ignore")
y = df["operational_status"]

# Remplacer les valeurs manquantes
X.fillna(0, inplace=True)

# Séparation
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardisation
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# Entraînement du modèle
model = MLPClassifier(hidden_layer_sizes=(50, 25), max_iter=500, random_state=42)
model.fit(X_train_scaled, y_train)

# Sauvegarde du modèle ET du scaler ensemble
joblib.dump((model, scaler), 'models/mlp_model.pkl')

print("✅ Modèle et scaler sauvegardés avec succès.")
