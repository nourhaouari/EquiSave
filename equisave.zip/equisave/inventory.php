<?php
include 'db.php';
$stmt = $pdo->query("SELECT * FROM products");
$products = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Inventaire - EquiSave</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    body {
      background: linear-gradient(to right, #f8fafc, #f1f5f9);
    }
  </style>
</head>

<body class="flex font-sans text-gray-800">

  <!-- Sidebar -->
  <aside class="w-64 h-screen bg-[#1e293b] text-white shadow-lg flex flex-col">
    <div class="text-3xl font-bold text-white px-6 py-6 border-b border-slate-700">EquiSave</div>
    <nav class="flex-1 px-6 py-6 space-y-6 text-lg tracking-wide">
      <a href="dashboard.php" class="block hover:text-sky-300">🏠 Dashboard</a>
      <a href="equipment.php" class="block hover:text-sky-300">🩺 Équipements</a>
      <a href="inventory.php" class="block font-semibold text-sky-400">📦 Inventaire</a>
      <a href="submissions.php" class="block hover:text-sky-300">📝 Soumissions</a>
      <a href="users.php" class="block hover:text-sky-300">👤 Utilisateurs</a>
      <a href="historique_maintenance.php" class="block hover:text-sky-300">🛠️ Historique Maintenance</a>
    </nav>
  </aside>

  <!-- Main content -->
  <main class="flex-1 p-10">

    <!-- Header -->
    <div class="flex justify-between items-center mb-10">
      <h1 class="text-4xl font-bold text-slate-800">📦 Inventaire des Produits</h1>
      <a href="add_product.php" class="bg-sky-600 text-white px-6 py-2 rounded-md text-base hover:bg-sky-700 transition">
        ➕ Ajouter un produit
      </a>
    </div>

    <!-- Table -->
    <div class="bg-white rounded-lg shadow-lg overflow-x-auto">
      <table class="min-w-full text-base text-left text-slate-700">
        <thead class="bg-slate-100 text-slate-600 uppercase text-xs">
          <tr>
            <th class="px-6 py-4">Nom</th>
            <th class="px-6 py-4">Catégorie</th>
            <th class="px-6 py-4">SKU</th>
            <th class="px-6 py-4">Prix</th>
            <th class="px-6 py-4">Description</th>
            <th class="px-6 py-4">Entrepôt</th>
            <th class="px-6 py-4">Enregistré par</th>
          </tr>
        </thead>
        <tbody class="divide-y divide-gray-100">
          <?php foreach ($products as $product): ?>
            <tr class="hover:bg-slate-50 transition">
              <td class="px-6 py-4 font-medium"><?= htmlspecialchars($product['product_name']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($product['category']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($product['sku']) ?></td>
              <td class="px-6 py-4 text-green-600 font-semibold"><?= number_format($product['price'], 2) ?> €</td>
              <td class="px-6 py-4"><?= htmlspecialchars($product['description']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($product['warehouse']) ?></td>
              <td class="px-6 py-4"><?= htmlspecialchars($product['registered_by']) ?></td>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>

  </main>
</body>
</html>
