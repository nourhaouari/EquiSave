import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
import joblib
import os

# Charger le fichier CSV
df = pd.read_csv("dataset_machines_médicales (1).csv")

# Afficher les noms de colonnes
print("Colonnes détectées :", df.columns.tolist())

# Identifier automatiquement la colonne cible
possible_targets = ['operational_status', 'status', 'statut', 'device_status']
target_col = None
for col in df.columns:
    if col.strip().lower() in possible_targets:
        target_col = col
        break

if not target_col:
    raise ValueError("❌ Colonne cible introuvable. Vérifiez le nom exact dans le fichier CSV.")

print(f"✅ Colonne cible utilisée : {target_col}")

# Supprimer les colonnes non numériques (automatiquement)
X = df.drop(columns=[target_col])
X = X.select_dtypes(include=['number'])  # Garder uniquement les colonnes numériques
y = df[target_col]

# Remplacer les valeurs manquantes
X.fillna(0, inplace=True)

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Standardisation
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)

# Entraînement du modèle
model = MLPClassifier(hidden_layer_sizes=(50, 25), max_iter=500, random_state=42)
model.fit(X_train_scaled, y_train)

# Sauvegarde
os.makedirs("models", exist_ok=True)
joblib.dump((model, scaler), "models/mlp_model.pkl")

print("✅ Modèle et scaler sauvegardés dans 'models/mlp_model.pkl'")

