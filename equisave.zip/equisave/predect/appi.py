from flask import Flask, request, jsonify
from flask_cors import CORS
import joblib
import numpy as np

app = Flask(__name__)
CORS(app)

model, scaler = joblib.load('models/mlp_model.pkl')

@app.route('/predict', methods=['POST'])
def make_prediction():
    try:
        input_data = request.json['input_data']
        input_scaled = scaler.transform([input_data])
        prediction = model.predict(input_scaled)
        label = str(prediction[0])  # ✅ plus de int()
        return jsonify({'prediction': label})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True)
