<?php
session_start();
include 'db.php';


// Traitement du formulaire
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $stmt = $pdo->prepare("
      INSERT INTO products (product_name, description, price, sku, category, photo_url, warehouse, registered_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  ");

  $stmt->execute([
      $_POST['product_name'],
      $_POST['description'],
      $_POST['price'],
      $_POST['sku'],
      $_POST['category'],
      $_POST['photo_url'] ?? null,
      $_POST['warehouse'],
      $_POST['registered_by']
  ]);

  header('Location: inventory.php');
  exit();
}

?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Ajouter un Produit - EquiSave</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100 flex">

  <!-- Sidebar -->
  <div class="w-64 h-screen bg-white shadow-lg flex flex-col">
    <div class="text-2xl font-bold p-6 border-b">EquiSave</div>
    <nav class="flex-1 p-4">
      <ul class="space-y-4">
        <li><a href="dashboard.php" class="block text-gray-700 hover:text-blue-600">🏠 Dashboard</a></li>
        <li><a href="equipment.php" class="block text-gray-700 hover:text-blue-600">🩺 Équipements</a></li>
        <li><a href="inventory.php" class="block text-gray-700 hover:text-blue-600">📦 Inventaire</a></li>
        <li><a href="submissions.php" class="block text-gray-700 hover:text-blue-600">📝 Soumissions</a></li>
        <li><a href="users.php" class="block text-gray-700 hover:text-blue-600">👤 Utilisateurs</a></li>
      </ul>
    </nav>
  </div>

  <!-- Contenu principal -->
  <div class="flex-1 p-8">
    <div class="flex justify-between items-center mb-8">
      <h1 class="text-3xl font-semibold">Ajouter un produit à l'inventaire</h1>
    </div>

    <!-- Formulaire -->
    <form method="POST" class="bg-white p-6 rounded-lg shadow space-y-6 max-w-lg mx-auto">
      <div>
        <label class="block mb-2 text-gray-700">Nom du produit</label>
        <input type="text" name="product_name" required class="w-full p-2 border rounded">
      </div>

      <div>
        <label class="block mb-2 text-gray-700">Description</label>
        <textarea name="description" rows="3" class="w-full p-2 border rounded"></textarea>
      </div>

      <div>
        <label class="block mb-2 text-gray-700">Prix (€)</label>
        <input type="number" step="0.01" name="price" required class="w-full p-2 border rounded">
      </div>

      <div>
        <label class="block mb-2 text-gray-700">SKU</label>
        <input type="text" name="sku" required class="w-full p-2 border rounded">
      </div>

      <div>
        <label class="block mb-2 text-gray-700">Catégorie</label>
        <input type="text" name="category" required class="w-full p-2 border rounded">
      </div>

      <div>
        <label class="block mb-2 text-gray-700">Lien vers la photo (URL)</label>
        <input type="url" name="photo_url" class="w-full p-2 border rounded">
      </div>
             <!-- WAREHOUSE (Manual entry) -->
      <div>
        <label class="block mb-2 text-gray-700">Entrepôt (Warehouse)</label>
         <input type="text" name="warehouse" class="w-full p-2 border rounded" required>
      </div>
      
      
      <input type="hidden" name="registered_by" value="<?= htmlspecialchars($_SESSION['user_name']) ?>">



      <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">✅ Ajouter le produit</button>
    </form>

  </div>

</body>
</html>
