<?php
include 'db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $job_title = $_POST['job_title'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Sécuriser

    $stmt = $pdo->prepare("INSERT INTO users (name, email, job_title, role, password_hash) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $email, $job_title, $role, $password]);

    $_SESSION['success'] = "Inscription réussie ! Vous pouvez maintenant vous connecter.";
    header('Location: login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Inscription - EquiSave</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="flex items-center justify-center min-h-screen bg-gray-100">

  <form method="POST" class="bg-white p-8 rounded shadow-lg space-y-6 w-full max-w-md">
    <h1 class="text-2xl font-bold text-center">Créer un compte</h1>

    <input type="text" name="name" placeholder="Nom" required class="w-full p-2 border rounded">
    <input type="email" name="email" placeholder="Email" required class="w-full p-2 border rounded">
    <input type="text" name="job_title" placeholder="Poste" required class="w-full p-2 border rounded">

    <select name="role" required class="w-full p-2 border rounded">
      <option value="Admin">Admin</option>
      <option value="Technician">Technicien</option>
      <option value="Engineer">Ingénieur</option>
      <option value="Specialist">Spécialiste</option>
    </select>

    <input type="password" name="password" placeholder="Mot de passe" required class="w-full p-2 border rounded">

    <button type="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">S'inscrire</button>

    <p class="text-center text-sm">Déjà inscrit ? <a href="login.php" class="text-blue-600">Connectez-vous</a></p>
  </form>

</body>
</html>
